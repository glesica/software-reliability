from .tictactoe import main

main()
